/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/JAIME DIAZ/Desktop/PROGRAMAS BASYS 2/mapasdekarnough4variables/variables4.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_2610679002_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    unsigned char t29;
    char *t30;
    char *t31;
    unsigned char t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 868U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t6);
    t8 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t7);
    t1 = (t0 + 2320);
    t9 = (t1 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t8;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(56, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 592U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t6);
    t1 = (t0 + 868U);
    t9 = *((char **)t1);
    t8 = *((unsigned char *)t9);
    t13 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t8);
    t14 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t13);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t4, t14);
    t1 = (t0 + 684U);
    t10 = *((char **)t1);
    t16 = *((unsigned char *)t10);
    t1 = (t0 + 868U);
    t11 = *((char **)t1);
    t17 = *((unsigned char *)t11);
    t18 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t17);
    t19 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t16, t18);
    t20 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t19);
    t1 = (t0 + 2356);
    t12 = (t1 + 32U);
    t21 = *((char **)t12);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = t20;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(57, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 868U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t6);
    t8 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t7);
    t1 = (t0 + 684U);
    t9 = *((char **)t1);
    t13 = *((unsigned char *)t9);
    t14 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t13);
    t1 = (t0 + 776U);
    t10 = *((char **)t1);
    t15 = *((unsigned char *)t10);
    t16 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t15);
    t17 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t14, t16);
    t18 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t8, t17);
    t1 = (t0 + 592U);
    t11 = *((char **)t1);
    t19 = *((unsigned char *)t11);
    t20 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t19);
    t1 = (t0 + 776U);
    t12 = *((char **)t1);
    t24 = *((unsigned char *)t12);
    t25 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t20, t24);
    t1 = (t0 + 868U);
    t21 = *((char **)t1);
    t26 = *((unsigned char *)t21);
    t27 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t26);
    t28 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t25, t27);
    t29 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t18, t28);
    t1 = (t0 + 2392);
    t22 = (t1 + 32U);
    t23 = *((char **)t22);
    t30 = (t23 + 40U);
    t31 = *((char **)t30);
    *((unsigned char *)t31) = t29;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(58, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 2428);
    t5 = (t1 + 32U);
    t9 = *((char **)t5);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t4;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(59, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 776U);
    t5 = *((char **)t1);
    t4 = *((unsigned char *)t5);
    t6 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t4);
    t1 = (t0 + 868U);
    t9 = *((char **)t1);
    t7 = *((unsigned char *)t9);
    t8 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t7);
    t13 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t6, t8);
    t1 = (t0 + 684U);
    t10 = *((char **)t1);
    t14 = *((unsigned char *)t10);
    t15 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t14);
    t1 = (t0 + 776U);
    t11 = *((char **)t1);
    t16 = *((unsigned char *)t11);
    t17 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t16);
    t18 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t17);
    t1 = (t0 + 868U);
    t12 = *((char **)t1);
    t19 = *((unsigned char *)t12);
    t20 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t19);
    t24 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t18, t20);
    t25 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t13, t24);
    t1 = (t0 + 592U);
    t21 = *((char **)t1);
    t26 = *((unsigned char *)t21);
    t27 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t26);
    t1 = (t0 + 684U);
    t22 = *((char **)t1);
    t28 = *((unsigned char *)t22);
    t29 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t27, t28);
    t1 = (t0 + 868U);
    t23 = *((char **)t1);
    t32 = *((unsigned char *)t23);
    t33 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t29, t32);
    t34 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t25, t33);
    t1 = (t0 + 2464);
    t30 = (t1 + 32U);
    t31 = *((char **)t30);
    t35 = (t31 + 40U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t34;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 684U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t4, t6);
    t1 = (t0 + 776U);
    t9 = *((char **)t1);
    t8 = *((unsigned char *)t9);
    t13 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t8);
    t14 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t13);
    t1 = (t0 + 776U);
    t10 = *((char **)t1);
    t15 = *((unsigned char *)t10);
    t16 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t15);
    t1 = (t0 + 868U);
    t11 = *((char **)t1);
    t17 = *((unsigned char *)t11);
    t18 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t17);
    t19 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t16, t18);
    t20 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t14, t19);
    t1 = (t0 + 2500);
    t12 = (t1 + 32U);
    t21 = *((char **)t12);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = t20;
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 2276);
    *((int *)t1) = 1;

LAB1:    return;
}


extern void work_a_2610679002_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2610679002_3212880686_p_0};
	xsi_register_didat("work_a_2610679002_3212880686", "isim/mapasde4variables_isim_beh.exe.sim/work/a_2610679002_3212880686.didat");
	xsi_register_executes(pe);
}
