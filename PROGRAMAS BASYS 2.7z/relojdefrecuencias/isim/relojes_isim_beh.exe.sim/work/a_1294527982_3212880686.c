/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/PROGRAMAS BASYS 2/relojdefrecuencias/relojes.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_1294527982_3212880686_p_0(char *t0)
{
    char t12[16];
    char t17[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned char t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 5265);
    t3 = (t0 + 3232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(48, ng0);
    t1 = (t0 + 992U);
    t9 = xsi_signal_has_event(t1);
    if (t9 == 1)
        goto LAB5;

LAB6:    t8 = (unsigned char)0;

LAB7:    if (t8 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3152);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1512U);
    t4 = *((char **)t2);
    t2 = (t0 + 5224U);
    t5 = (t0 + 5269);
    t7 = (t12 + 0U);
    t13 = (t7 + 0U);
    *((int *)t13) = 0;
    t13 = (t7 + 4U);
    *((int *)t13) = 15;
    t13 = (t7 + 8U);
    *((int *)t13) = 1;
    t14 = (15 - 0);
    t15 = (t14 * 1);
    t15 = (t15 + 1);
    t13 = (t7 + 12U);
    *((unsigned int *)t13) = t15;
    t16 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t4, t2, t5, t12);
    if (t16 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t8);
    t1 = (t0 + 3360);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = t9;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 5285);
    t3 = (t0 + 3296);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 15U);
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t1 = (t0 + 3424);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = t8;
    xsi_driver_first_trans_fast_port(t1);

LAB9:    goto LAB3;

LAB5:    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t10 = *((unsigned char *)t3);
    t11 = (t10 == (unsigned char)3);
    t8 = t11;
    goto LAB7;

LAB8:    xsi_set_current_line(50, ng0);
    t13 = (t0 + 1512U);
    t18 = *((char **)t13);
    t13 = (t0 + 5224U);
    t19 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t17, t18, t13, 1);
    t20 = (t17 + 12U);
    t15 = *((unsigned int *)t20);
    t21 = (1U * t15);
    t22 = (15U != t21);
    if (t22 == 1)
        goto LAB11;

LAB12:    t23 = (t0 + 3296);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t19, 15U);
    xsi_driver_first_trans_fast(t23);
    goto LAB9;

LAB11:    xsi_size_not_matching(15U, t21, 0);
    goto LAB12;

}


extern void work_a_1294527982_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1294527982_3212880686_p_0};
	xsi_register_didat("work_a_1294527982_3212880686", "isim/relojes_isim_beh.exe.sim/work/a_1294527982_3212880686.didat");
	xsi_register_executes(pe);
}
